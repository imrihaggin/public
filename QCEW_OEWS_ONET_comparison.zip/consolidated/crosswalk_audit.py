"""Check endpoint classifications, coverage and O*NET profile sensitivity offline."""
from pathlib import Path

import numpy as np
import pandas as pd

root = Path(__file__).resolve().parent
inputs, results = root / 'inputs', root / 'results'
benchmark = pd.read_csv(results / 'private_benchmark.csv').set_index('soc')
occupations = pd.read_csv(inputs / 'occupation_merge.csv').set_index('soc')
activity = pd.read_csv(inputs / 'activity_dictionary.csv').set_index('Element ID')['activity']
groups = set(benchmark.index.str[:2])
private, industries = {}, {}
for year in (2022, 2025):
    table = pd.read_csv(inputs / f'private_{year % 100}.csv', dtype=str)
    detailed = table.loc[table.O_GROUP.eq('detailed')].set_index('OCC_CODE', verify_integrity=True)
    detailed['TOT_EMP'] = pd.to_numeric(detailed.TOT_EMP, errors='coerce')
    private[year] = detailed.loc[detailed.index.str[:2].isin(groups), ['OCC_TITLE', 'TOT_EMP']]
    q = pd.read_csv(inputs / f'qcew_{year}Q2.csv', dtype=str)
    rows = q.loc[q.area_fips.eq('US000') & q.own_code.eq('5') & q.size_code.eq('0')
                 & q.agglvl_code.eq('16') & q.disclosure_code.ne('N')]
    industries[year] = set(rows.loc[rows.month2_emplvl.notna(), 'industry_code'])

endpoints = private[2022].join(private[2025], how='outer', lsuffix='_22', rsuffix='_25')
endpoints['in_activity_comparison'] = endpoints.index.isin(benchmark.index)
endpoints['same_title'] = endpoints.OCC_TITLE_22.eq(endpoints.OCC_TITLE_25)
endpoints['onet_profiles'] = occupations.onet_suboccupations
endpoints.index.name = 'soc'
endpoints.to_csv(results / 'crosswalk_occupations.csv')
industry_codes = sorted(industries[2022] | industries[2025])
pd.DataFrame({'naics': industry_codes, **{
    f'present_{year}': [code in codes for code in industry_codes]
    for year, codes in industries.items()
}}).to_csv(results / 'crosswalk_industries.csv', index=False)

coverage = []
complete = endpoints.dropna(subset=['TOT_EMP_22', 'TOT_EMP_25'])
for name, panel in [('published_private', complete), ('activity_comparison', complete.loc[benchmark.index])]:
    loss = (panel.TOT_EMP_22 - panel.TOT_EMP_25).clip(lower=0)
    office_loss = loss[loss.index.str.startswith('43')].sum()
    coverage.append([name, len(panel), loss.sum(), office_loss, 100 * office_loss / loss.sum()])
pd.DataFrame(coverage, columns=['sample', 'occupations', 'summed_declines', 'office_declines',
                                 'office_pct_of_declines']).to_csv(results / 'crosswalk_coverage.csv', index=False)

panel = occupations.loc[benchmark.index]
gaps = pd.DataFrame({'activity': activity})
for name, sample in [('all_matched', panel), ('one_onet_profile', panel.loc[panel.onet_suboccupations.eq(1)])]:
    ratings = sample[activity.index]
    jobs = benchmark.loc[sample.index, 'private_22']
    losses = (-benchmark.loc[sample.index, 'private_change']).clip(lower=0)
    mean = ratings.mul(jobs, axis=0).sum() / jobs.sum()
    sd = np.sqrt(ratings.sub(mean).pow(2).mul(jobs, axis=0).sum() / jobs.sum())
    gaps[f'{name}_occupations'] = len(sample)
    gaps[f'{name}_gap_sd'] = (ratings.mul(losses, axis=0).sum() / losses.sum() - mean) / sd
original = pd.read_csv(results / 'activity_results.csv').query('run == "private_oews_common"').set_index('element')
np.testing.assert_allclose(gaps.all_matched_gap_sd, original.loc[gaps.index, 'gap_sd'])
gaps.to_csv(results / 'crosswalk_activity_sensitivity.csv')

insurance = pd.read_csv(inputs / 'insurance_carriers.csv').pivot(index='year', columns='OCC_CODE', values='TOT_EMP')
insurance.columns.name = None
insurance = insurance.rename(columns={'00-0000': 'all_jobs', '43-4051': 'customer_service_jobs'})
insurance['customer_service_pct'] = 100 * insurance.customer_service_jobs / insurance.all_jobs
insurance.to_csv(results / 'insurance_staffing.csv')
