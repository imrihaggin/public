"""Run from any directory. Uses the bundled inputs offline."""
from pathlib import Path
import numpy as np
import pandas as pd
from allocate_jobs import allocate, build_staffing, qcew_months, UNALLOCATED

root = Path(__file__).resolve().parent
inputs, out = root/'inputs', root/'results'
out.mkdir(exist_ok=True)
groups = ['11','13','15','17','19','23','27','41','43']
activity = pd.read_csv(inputs/'activity_dictionary.csv').set_index('Element ID').activity
cols = activity.index.tolist()
occ = pd.read_csv(inputs/'occupation_merge.csv', dtype={'major':str}).set_index('soc')
staff, _ = build_staffing(pd.read_csv(inputs/'oews_2025_private_staffing.csv', dtype=str))
months, audits = zip(*(qcew_months(pd.read_csv(p,dtype=str)) for p in sorted(inputs.glob('qcew_*.csv'))))
controls=pd.concat(audits).set_index('month')
jobs=pd.concat(months,ignore_index=True)
model, contributions = allocate(jobs,staff)
status = contributions.groupby(['month','allocation_status']).modeled_employment.sum().unstack(fill_value=0)
coverage=controls.join(status)
assert np.allclose(controls.private_total, status.sum(axis=1))
coverage['assigned_pct']=100*status.allocated/coverage.private_total
coverage.to_csv(out/'reconciliation.csv')
head = model.pivot(index='occupation',columns='month',values='modeled_employment')
assert len(head.columns)==51 and head.notna().all().all()
titles=model.drop_duplicates('occupation').set_index('occupation').occupation_title
head.join(titles).to_csv(out/'monthly_headcounts.csv')
for date in ['2022-05','2025-05','2022-03','2025-03','2026-03']:
    occ['model_'+date] = head[date]
for yr in ['22','25']:
    p=pd.read_csv(inputs/f'private_{yr}.csv',dtype=str)
    p=p[p.O_GROUP.eq('detailed')].set_index('OCC_CODE')
    occ['private_'+yr]=pd.to_numeric(p.TOT_EMP,errors='coerce')

original=occ[occ['major'].isin(groups) & occ.matched_activities.eq(41) & occ.emp_2022.gt(0) & occ.emp_2025.notna()]
common=original.dropna(subset=['private_22','private_25','model_2022-05','model_2025-05','model_2026-03'])
assert (common[['private_22','private_25','model_2022-05','model_2025-05','model_2026-03']]>0).all().all()
stats, activities, drivers, occupations = [], [], [], []
def profile(s, label, start, end):
    s=s.copy()
    b=s[start]; finish=s[end]; delta=finish-b; loss=(-delta).clip(lower=0)
    x=s[cols]
    base=x.mul(b,axis=0).sum()/b.sum()
    sd=(x.sub(base).pow(2).mul(b,axis=0).sum()/b.sum())**0.5
    lm=x.mul(loss,axis=0).sum()/loss.sum()
    mix=sum(x.loc[g.index].mul(b[g.index],axis=0).sum()/b[g.index].sum()*(loss[g.index].sum()/loss.sum()) for _,g in s.groupby('major'))
    a=pd.DataFrame({'activity':activity,'baseline_importance':base,'contraction_importance':lm,
                    'gap_sd':(lm-base)/sd,'within_major_gap_sd':(lm-mix)/sd}).rename_axis('element').reset_index()
    activities.append(a.assign(run=label))
    detail=pd.DataFrame({'title':s.title,'major':s.major,'start_jobs':b,'end_jobs':finish,'net_change':delta,'contraction':loss})
    occupations.append(detail.reset_index().assign(run=label))
    g=detail.groupby('major')[['start_jobs','end_jobs','net_change','contraction']].sum()
    g['baseline_pct']=100*g.start_jobs/b.sum();g['contraction_pct']=100*g.contraction/loss.sum()
    drivers.append(g.reset_index().assign(run=label))
    stats.append(dict(run=label,n=len(s),shrinking=sum(delta<0),start_jobs=b.sum(),end_jobs=finish.sum(),net_change=delta.sum(),summed_contractions=loss.sum(),office_baseline_pct=g.loc['43','baseline_pct'],office_contraction_pct=g.loc['43','contraction_pct']))
    return a
orig=profile(original,'original_all_ownership','emp_2022','emp_2025')
chk=orig.merge(pd.read_csv(inputs/'original_nine_results.csv'),on='element')
assert len(chk)==41 and np.allclose(chk.gap_sd_x,chk.gap_sd_y) and np.allclose(chk.within_major_gap_sd_x,chk.within_major_gap_sd_y)
for label,start,end in [('all_ownership_common','emp_2022','emp_2025'),('private_oews_common','private_22','private_25'),('qcew_common','model_2022-05','model_2025-05'),('qcew_latest_yoy','model_2025-03','model_2026-03'),('qcew_march_2022_2026','model_2022-03','model_2026-03')]:
    profile(common,label,start,end)
model_sample=original.dropna(subset=['model_2022-05','model_2025-05'])
profile(model_sample,'qcew_original_available','model_2022-05','model_2025-05')
pd.concat(activities).to_csv(out/'activity_results.csv',index=False)
pd.DataFrame(stats).to_csv(out/'summary.csv',index=False)
pd.concat(drivers).to_csv(out/'major_groups.csv',index=False)
pd.concat(occupations).to_csv(out/'occupation_drivers.csv',index=False)
diag=common[['title','major','private_22','private_25','model_2022-05','model_2025-05','model_2026-03']].copy()
diag['private_change']=diag.private_25-diag.private_22
diag['model_change']=diag['model_2025-05']-diag['model_2022-05']
diag['private_growth_pct']=100*diag.private_change/diag.private_22
diag['model_growth_pct']=100*diag.model_change/diag['model_2022-05']
diag.to_csv(out/'private_benchmark.csv')
excluded=original.loc[~original.index.isin(common.index),['title','major','private_22','private_25','model_2022-05','model_2025-05']]
excluded.to_csv(out/'excluded_from_common.csv')
b=[]
for year in ['22','25']:
    actual=diag['private_'+year];pred=diag['model_20'+year+'-05']
    b.append(dict(measure='level_comparison',year='20'+year,actual=actual.sum(),model=pred.sum(),ratio=pred.sum()/actual.sum(),pearson=actual.corr(pred),weighted_abs_error=(pred-actual).abs().sum()/actual.sum()))
nz=diag.private_change.ne(0)&diag.model_change.ne(0)
b.append(dict(measure='2022_25_growth_rate',pearson=diag.private_growth_pct.corr(diag.model_growth_pct),spearman=diag.private_growth_pct.corr(diag.model_growth_pct,method='spearman'),sign_agreement=(np.sign(diag.private_change[nz])==np.sign(diag.model_change[nz])).mean(),non_ties=nz.sum(),shrinking_recall=((diag.private_change<0)&(diag.model_change<0)).sum()/(diag.private_change<0).sum()))
pd.DataFrame(b).to_csv(out/'benchmark_checks.csv',index=False)

# Companion samples use precisely the same profile calculation. The nine-group
# outputs above remain the primary comparison used in the article.
for scope, majors in [('national',set(occ.major)), ('seven_professional',set(groups[:-2]))]:
    original_scope=occ[occ.major.isin(majors) & occ.matched_activities.eq(41) & occ.emp_2022.gt(0) & occ.emp_2025.notna()]
    matched=original_scope.dropna(subset=['private_22','private_25','model_2022-05','model_2025-05','model_2026-03'])
    for label,start,end in [('private_oews','private_22','private_25'),('qcew','model_2022-05','model_2025-05'),('qcew_latest_yoy','model_2025-03','model_2026-03')]:
        s=matched
        base=s[start].to_numpy(); loss=(s[start]-s[end]).clip(lower=0).to_numpy()
        x=s[cols].to_numpy(); avg=np.average(x,axis=0,weights=base)
        sd=np.sqrt(np.average((x-avg)**2,axis=0,weights=base))
        lm=np.average(x,axis=0,weights=loss)
        cf=np.zeros_like(avg)
        for m in s.major.unique():
            idx=s.major.eq(m).to_numpy()
            cf+=loss[idx].sum()/loss.sum()*np.average(x[idx],axis=0,weights=base[idx])
        pd.DataFrame({'element':cols,'activity':activity.values,'gap_sd':(lm-avg)/sd,'within_major_gap_sd':(lm-cf)/sd,'occupations':len(s),'contractions':loss.sum()}).to_csv(out/f'{scope}_{label}.csv',index=False)
