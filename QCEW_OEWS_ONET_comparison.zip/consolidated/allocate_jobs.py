"""Public-data occupational employment allocation; not a Lightcast replica.

National private QCEW employment times fixed national OEWS staffing shares.
Missing occupational detail remains unallocated. No suppression imputation.
"""
from pathlib import Path
import argparse
import numpy as np
import pandas as pd

UNALLOCATED = 'UNALLOCATED'
# Official combined-industry definitions printed in May 2025 OEWS titles.
# Their common staffing pattern is applied to each constituent QCEW industry.
INDUSTRY_GROUPS = {
    '3250A1': ['3251','3252','3253','3259'], '3250A2': ['3255','3256'],
    '3320A1': ['3321','3322','3325','3326','3329'], '3320A2': ['3323','3324'],
    '3330A1': ['3331','3332','3334','3339'], '3370A1': ['3371','3372'],
    '4230A1': ['4232','4233','4235','4236','4237','4239'],
    '4240A1': ['4244','4248'], '4240A2': ['4242','4246'],
    '4240A3': ['4241','4247','4249'], '4450A1': ['4451','4452'],
    '4590A1': ['4594','4595'], '5220A1': ['5221','5223'],
    '5320A1': ['5322','5323','5324'],
}


def numeric(series):
    return pd.to_numeric(series.astype(str).str.replace(',', '', regex=False), errors='coerce')


def build_staffing(oews):
    """Use private industry NAICS, detailed SOC and all-occupation totals.

    OEWS writes a 4-digit code as six digits ending 00. Never mix SOC levels.
    Consistent duplicate publications are collapsed; conflicting ones fail.
    """
    d = oews.copy()
    d['OWN_CODE'] = numeric(d['OWN_CODE'])
    d = d[d.OWN_CODE.eq(5)].copy()
    code = d.NAICS.astype(str).str.replace(r'\.0$', '', regex=True)
    is3 = d['I_GROUP'].str.startswith('3-digit') if 'I_GROUP' in d else pd.Series(False, index=d.index)
    ordinary = code.str.fullmatch(r'\d{4}00') & ~is3
    three = code.str.fullmatch(r'\d{3}000') & is3
    if not (ordinary | three | code.isin(INDUSTRY_GROUPS)).all():
        raise ValueError('Unexpected industry code; update and verify the combined-industry crosswalk')
    d['industry'] = code.where(~ordinary, code.str[:4])
    d.loc[three, 'industry'] = code[three].str[:3]
    for combined, members in INDUSTRY_GROUPS.items():
        titles = d.loc[d.industry.eq(combined), 'NAICS_TITLE'].unique()
        if len(titles):
            import re
            if any(set(re.findall(r'\b\d{4}\b', t)) != set(members) for t in titles):
                raise ValueError(f'{combined}: title does not match the declared crosswalk')
    d['employment'] = numeric(d.TOT_EMP)
    if (d.employment.dropna() < 0).any():
        raise ValueError('Negative employment')
    if d.groupby(['industry', 'OCC_CODE']).TOT_EMP.nunique(dropna=False).gt(1).any():
        raise ValueError('Conflicting duplicate OEWS occupation-industry cells')
    d = d.drop_duplicates(['industry', 'OCC_CODE'])
    totals = d[d.O_GROUP.eq('total')].set_index('industry')
    details = d[d.O_GROUP.eq('detailed') & d.employment.notna()]
    records, audit = [], []
    for industry, totalrow in totals.iterrows():
        total = totalrow.employment
        if not np.isfinite(total) or total <= 0:
            continue
        g = details[details.industry.eq(industry)]
        published_sum = g.employment.sum()
        # OEWS counts are independently rounded. Permit only a small excess.
        if published_sum > total * 1.005:
            raise ValueError(f'{industry}: detailed employment exceeds total by >0.5%')
        denominator = max(total, published_sum)
        for row in g.itertuples():
            records.append([industry, row.OCC_CODE, row.OCC_TITLE,
                            row.employment / denominator])
        residual = max(0.0, 1 - published_sum / denominator)
        if residual > 0:
            records.append([industry, UNALLOCATED, 'Unallocated employment', residual])
        audit.append([industry, totalrow.NAICS_TITLE, total, published_sum,
                      residual, published_sum > total])
    s = pd.DataFrame(records, columns=['industry', 'occupation', 'occupation_title', 'share'])
    if s.empty:
        raise ValueError('No usable staffing patterns')
    if not np.allclose(s.groupby('industry').share.sum(), 1, atol=1e-10):
        raise AssertionError('Staffing shares do not sum to one')
    a = pd.DataFrame(audit, columns=['industry', 'industry_title', 'oews_total',
                     'published_detailed_sum', 'unallocated_share', 'rounding_adjustment'])
    return s, a


def qcew_months(qcew):
    """National private employment only; agglvl 16 prevents supersector duplication.

    Missing/suppressed industry counts are NOT treated as observed zeros.
    The difference from the disclosed private total is retained separately.
    """
    q = qcew.copy().fillna('')
    for col in ['own_code', 'agglvl_code', 'size_code', 'year', 'qtr']:
        q[col] = numeric(q[col])
    q = q[q.area_fips.eq('US000') & q.own_code.eq(5) & q.size_code.eq(0)]
    if q[['year', 'qtr']].drop_duplicates().shape[0] != 1:
        raise ValueError('Supply one national QCEW quarter per file')
    total = q[q.industry_code.eq('10') & q.agglvl_code.eq(11)]
    if len(total) != 1 or total.iloc[0].disclosure_code == 'N':
        raise ValueError('A unique disclosed private-sector total is required')
    g = q[q.agglvl_code.eq(16)].copy()
    if g.industry_code.duplicated().any():
        raise ValueError('Duplicate four-digit industries')
    if not g.industry_code.str.fullmatch(r'\d{4}').all():
        raise ValueError('Unexpected QCEW industry codes')
    year, quarter = int(total.iloc[0].year), int(total.iloc[0].qtr)
    records, audit = [], []
    for m in (1, 2, 3):
        date = f'{year}-{3*(quarter-1)+m:02d}'
        col = f'month{m}_emplvl'
        values = numeric(g[col])
        usable = g.disclosure_code.ne('N') & values.notna()
        total_jobs = float(total.iloc[0][col])
        published_jobs = values[usable].sum()
        if (values[usable] < 0).any() or published_jobs > total_jobs + 0.01:
            raise ValueError('Invalid four-digit employment total')
        for industry, jobs in zip(g.loc[usable, 'industry_code'], values[usable]):
            records.append([date, industry, float(jobs)])
        residual = max(0, total_jobs - published_jobs)
        if residual:
            records.append([date, 'QCEW_UNASSIGNED', residual])
        audit.append([date, total_jobs, published_jobs, residual,
                      int((~usable).sum())])
    return (pd.DataFrame(records, columns=['month', 'industry', 'industry_employment']),
            pd.DataFrame(audit, columns=['month', 'private_total', 'published_4digit_total',
                                        'qcew_unassigned', 'unpublished_industry_rows']))


def allocate(industry_jobs, staffing):
    """E[o,t] = sum_i E[i,t] * share[o|i]. Keep contributions for auditing."""
    if industry_jobs.duplicated(['month', 'industry']).any():
        raise ValueError('Duplicate industry-month rows')
    if staffing.duplicated(['industry', 'occupation']).any():
        raise ValueError('Duplicate staffing cells')
    if (staffing.share < 0).any() or not np.isfinite(staffing.share).all():
        raise ValueError('Invalid staffing shares')
    if not np.allclose(staffing.groupby('industry').share.sum(), 1, atol=1e-10):
        raise ValueError('Staffing shares must sum to one')
    if (industry_jobs.industry_employment < 0).any() or not np.isfinite(industry_jobs.industry_employment).all():
        raise ValueError('Invalid industry employment')
    jobs = industry_jobs.copy()
    available = set(staffing.industry)
    lookup = {member: group for group, members in INDUSTRY_GROUPS.items()
              if group in available for member in members}
    # Prefer a published exact match if a later source provides one.
    def pattern(x):
        # Agriculture has material OEWS coverage gaps: do not apply partial
        # agricultural staffing patterns to all QCEW agricultural jobs.
        if x.startswith('11'):
            return 'AGRICULTURE_OUT_OF_SCOPE'
        if x in available:
            return x
        if x in lookup:
            return lookup[x]
        return x[:3] if x[:3] in available else x
    jobs['staffing_industry'] = jobs.industry.map(pattern)
    jobs['pattern_match'] = np.where(jobs.staffing_industry.eq(jobs.industry), 'exact_4digit',
                           np.where(jobs.staffing_industry.str.len().eq(3), 'parent_3digit', 'combined_or_unmatched'))
    c = jobs.merge(staffing.rename(columns={'industry': 'staffing_industry'}),
                   on='staffing_industry', how='left')
    missing = c.occupation.isna()
    c['allocation_status'] = np.where(missing, 'no_matching_staffing_pattern',
                            np.where(c.occupation.eq(UNALLOCATED), 'unpublished_oews_detail', 'allocated'))
    c.loc[missing, 'occupation'] = UNALLOCATED
    c.loc[missing, 'occupation_title'] = 'Unallocated employment'
    c.loc[missing, 'share'] = 1.0
    c['modeled_employment'] = c.industry_employment * c.share
    result = c.groupby(['month', 'occupation', 'occupation_title'], as_index=False).modeled_employment.sum()
    expected = industry_jobs.groupby('month').industry_employment.sum()
    actual = result.groupby('month').modeled_employment.sum().reindex(expected.index)
    if not np.allclose(actual, expected, rtol=1e-12, atol=1e-5):
        raise AssertionError('Employment allocation does not preserve totals')
    return result, c


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--staffing', type=Path, default=Path('data/oews_2025_private_staffing.csv'))
    p.add_argument('--qcew', nargs='+', type=Path,
                   default=[Path('data/qcew_2025Q1.csv'), Path('data/qcew_2026Q1.csv')])
    p.add_argument('--out', type=Path, default=Path('output'))
    args = p.parse_args()
    staffing, sa = build_staffing(pd.read_csv(args.staffing, dtype=str))
    pieces = [qcew_months(pd.read_csv(f, dtype=str)) for f in args.qcew]
    jobs = pd.concat([x[0] for x in pieces], ignore_index=True)
    qa = pd.concat([x[1] for x in pieces], ignore_index=True)
    modeled, contributions = allocate(jobs, staffing)
    coverage = contributions.groupby(['month', 'allocation_status']).modeled_employment.sum().unstack(fill_value=0)
    coverage['allocated_pct'] = 100 * coverage.get('allocated', 0) / coverage.sum(axis=1)
    compare = modeled.pivot(index=['occupation', 'occupation_title'], columns='month', values='modeled_employment').fillna(0)
    dates = sorted(compare.columns)
    compare['change_first_to_last'] = compare[dates[-1]] - compare[dates[0]]
    compare['change_pct_first_to_last'] = 100 * compare.change_first_to_last / compare[dates[0]].replace(0, np.nan)
    # Same-month year-over-year comparisons avoid mistaking seasonality for trend.
    for date in dates:
        prior = f'{int(date[:4])-1}{date[4:]}'
        if prior in dates:
            compare[f'change_{prior}_to_{date}'] = compare[date] - compare[prior]
            compare[f'pct_{prior}_to_{date}'] = 100 * (compare[date]/compare[prior].replace(0, np.nan)-1)
    args.out.mkdir(parents=True, exist_ok=True)
    for name, frame in [('staffing_shares', staffing), ('staffing_audit', sa),
                        ('industry_months', jobs), ('qcew_audit', qa),
                        ('modeled_occupation_months', modeled), ('industry_contributions', contributions)]:
        frame.to_csv(args.out / f'{name}.csv', index=False)
    coverage.to_csv(args.out / 'coverage.csv')
    compare.to_csv(args.out / 'occupation_changes.csv')
    print(coverage.to_string())
    print(f'Wrote {len(modeled):,} occupation-month estimates; totals reconcile including UNALLOCATED.')


if __name__ == '__main__':
    main()
