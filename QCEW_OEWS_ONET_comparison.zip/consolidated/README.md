# Occupational employment and O*NET work activities

Start with **README_QCEW.md** for the choice of employment weights. The main comparison covers 263 U.S. private-sector occupations across nine occupational groups, May 2022 to May 2025. The monthly QCEW scenario extends through March 2026.

## Reproduce the package

From this directory, run the following with Python 3.10 or later. All analysis inputs are included.

```sh
python -m pip install -r requirements.txt
python rerun.py
python crosswalk_audit.py
python figure.py
```

To rebuild the underlying O*NET profile merge from its original activity ratings and national OEWS workbooks, run `python original_analysis/analyze.py`. It writes its outputs in `original_analysis/results/`. The main analysis uses the bundled copy at `inputs/occupation_merge.csv`.

## Classification and coverage checks

Both OEWS endpoints use the 2018 SOC. May 2022 was the first OEWS release on 2022 NAICS. BLS mapped its six earlier survey panels from 2017 NAICS to the new codes. QCEW uses 2022 NAICS from 2022 forward. Identical published codes can still include changes in establishment assignments, survey responses and occupational staffing. [BLS 2022 transition note](https://www.bls.gov/oes/2022/may/oes_tec.htm) · [QCEW classification vintages](https://www.bls.gov/cew/classifications/industry/industry-titles.htm)

- `crosswalk_occupations.csv` and `crosswalk_industries.csv` in `results/` compare the employment-source codes. All 263 occupations in the main sample retain the same private OEWS code and title. All 301 national private four-digit QCEW industry codes appear at both endpoints.
- O*NET ratings describe 41 **generalized work activities**. Multiple O*NET occupations can fall under one OEWS code. The main results give those profiles equal weight. Some OEWS codes combine occupations that O*NET rates separately, such as buyers and purchasing agents. An exact-code join leaves those groups out.
- `crosswalk_activity_sensitivity.csv` recomputes all 41 standardized gaps for the 220 occupations with one O*NET profile. Administrative activities remain more important in shrinking occupations (+0.19 SD, versus +0.23 SD in the full matched sample). Coaching remains less important (−0.43 versus −0.48 SD).
- `crosswalk_coverage.csv` removes the requirement for activity ratings and modeled headcounts. Among all 285 occupations in the nine groups with private OEWS employment published in both years, office support accounts for 61.2% of summed declines, compared with 62.1% in the 263-occupation sample.

## Read the files
- monthly_headcounts.csv in results contains monthly private QCEW-implied jobs for January 2022 through March 2026, including the unallocated balance. Fractional jobs reflect allocation. Each month's sum reconciles to national private QCEW.
- summary.csv, major_groups.csv and occupation_drivers.csv show the coverage and drivers of the nine-group comparisons. activity_results.csv includes all 41 importance gaps, before and after matching occupational-family composition. activity_comparison.png shows selected results. In the summary, summed contractions add only declines in occupations whose employment fell. Growing occupations do not offset them.
- private_benchmark.csv gives matched model and private OEWS levels/growth by occupation. benchmark_checks.csv reports level fit and growth diagnostics. excluded_from_common.csv identifies the 14 original occupations without complete cross-source coverage. Companion national and seven-professional-group CSVs cover all 41 activities on the respective common samples.
- The main historical comparison is May 2022 to May 2025. The March 2025 to March 2026 comparison uses the same month to reduce seasonality. These data are not seasonally adjusted. Full series coverage ends with 2026 Q1. The nine-group original analysis has 277 occupations, 268 have matched modeled headcounts and 263 also have complete private OEWS benchmarks. The main comparisons use those same 263 throughout.
- The original full-ownership benchmark is rerun and checked against its archived 41 overall and within-family standardized gaps. Each activity is rated on the O*NET 1–5 importance scale. Its gap is its contraction-weighted mean minus its start-employment-weighted mean, divided by the start-employment-weighted population SD. The within-family gap replaces the start employment mix with the contraction mix of major families while preserving each family's own starting occupational mix. Published residuals use the same source-specific baseline SD.
- Benchmark sign agreement excludes ties. The level checks compare summed model jobs and summed private OEWS jobs on the common sample. Growth correlations are unweighted across occupational codes. May 2025 level fit is partly mechanical because the staffing and benchmark data come from the same OEWS vintage. Changes in a fixed-share model can diverge materially from observed occupational changes. OEWS comparisons themselves use pooled survey estimates.

## Inputs, scope and assumptions
The QCEW area slices come from https://data.bls.gov/cew/data/api/YEAR/QUARTER/area/US000.csv for all 17 quarters. The OEWS industry and private national ownership tables come from the BLS national industry archives at https://www.bls.gov/oes/tables.htm (oesm22in4.zip and oesm25in4.zip). The archived occupation_merge.csv and activity_dictionary.csv retain the original O*NET 31.0 importance ratings matched to May 2022–25 OEWS. Detailed O*NET-SOC subtypes are averaged within six-digit SOC, excluding suppressed ratings. Only occupations with all 41 comparable activities enter profiles. The nine major groups are 11, 13, 15, 17, 19, 23, 27, 41 and 43.

allocate_jobs.py is the earlier public model's allocation code. It applies fixed private May 2025 staffing to each industry's monthly QCEW employment, retrospectively for early months. Combined-industry patterns and then three-digit parent patterns fill available industry matches. Agricultural and unmatched employment and unpublished occupational detail remain unallocated. Aggregate sums including this balance reconcile in every month. The estimates cover private payroll jobs and are distinct from counts of workers. California claimant classification plays no role in this analysis.

Methods and calendar: https://www.bls.gov/opub/hom/oews/calculation.htm and https://www.bls.gov/cew/release-calendar.htm .

The activity ratings come from the O*NET® 31.0 Database, National Center for O*NET Development, used under CC BY 4.0. The analysis selects importance ratings, excludes suppressed values, averages suboccupations and calculates employment-weighted comparisons. [O*NET Database license](https://www.onetcenter.org/license_db.html) · [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/)
