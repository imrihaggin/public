from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
p=Path(__file__).resolve().parent/'results'
a=pd.read_csv(p/'activity_results.csv').pivot(index='activity',columns='run',values='gap_sd')
items={'Performing Administrative Activities':'Administrative work','Selling or Influencing Others':'Selling or influencing others','Establishing and Maintaining Interpersonal Relationships':'Maintaining relationships','Analyzing Data or Information':'Analyzing data or information','Coaching and Developing Others':'Coaching and developing others','Guiding, Directing, and Motivating Subordinates':'Directing staff','Developing Objectives and Strategies':'Developing strategy'}
fig,ax=plt.subplots(figsize=(9,5.5))
fig.subplots_adjust(left=.32,right=.96,top=.75,bottom=.21)
for y,(full,title) in enumerate(items.items()):
    x1,x2=a.loc[full,['private_oews_common','qcew_common']]
    ax.plot([x1,x2],[y,y],color='#afb9bc',lw=2)
    ax.scatter(x1,y,color='#185672',s=68,zorder=3)
    ax.scatter(x2,y,color='#c16829',s=64,marker='D',zorder=3)
ax.set_yticks(range(len(items)),list(items.values()));ax.invert_yaxis();ax.set_xlim(-.85,.65);ax.axvline(0,lw=.8,color='#686f73');ax.grid(axis='x',alpha=.16);ax.set_axisbelow(True)
ax.set_xlabel('Difference in activity importance from the starting job mix (standard deviations)',fontsize=10,labelpad=9)
for s in ax.spines.values():s.set_visible(False)
ax.tick_params(length=0)
fig.text(.04,.94,'Administrative work changes sides when employment is inferred from industries',fontsize=14,weight='bold')
fig.text(.04,.885,'263 matched occupations across nine groups  |  U.S. private sector  |  May 2022 to May 2025',fontsize=10)
fig.legend(handles=[Line2D([],[],color='#185672',marker='o',ls='',label='Private OEWS'),Line2D([],[],color='#c16829',marker='D',ls='',label='QCEW with fixed May 2025 staffing')],loc='upper left',bbox_to_anchor=(.035,.86),ncol=2,frameon=False)
fig.text(.04,.055,'Positive values indicate greater importance in occupations with contracting employment. Selected from 41 O*NET activities.',fontsize=9)
fig.text(.04,.02,'Sources: BLS OEWS and QCEW, O*NET 31.0, and calculations.',fontsize=8.5)
fig.savefig(p/'activity_comparison.png',dpi=180)
