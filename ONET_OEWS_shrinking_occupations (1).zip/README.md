# Which activities characterize shrinking occupations?

Prepared for Imri Haggin, 16 November 2026.

## Result

The previous package had not merged an employment outcome. This package merges O*NET 31.0 generalized work activity importance with BLS national Occupational Employment and Wage Statistics (OEWS, formerly OES), May 2022, 2023, 2024 and 2025. It uses observed employment estimates, not employment projections or Anthropic task penetration.

Across 756 complete matched occupations, administrative activities (+0.220 standard deviations), working with computers (+0.192), and processing information (+0.163) are the three most overrepresented activities in the profile of occupational employment contractions from May 2022 to May 2025. Coaching and developing others (-0.512), developing/building teams (-0.466), assisting/caring for others (-0.438), and directing/motivating subordinates (-0.429) are the four most underrepresented. These are calculated associations, not estimates of tasks eliminated.

This supports a descriptive account of contraction concentrated in administrative and information-processing occupations, with less weight on people-development responsibilities. It does not establish that AI caused this pattern or that experience itself protects a worker.

## The nine groups from the draft

Scope: management (11), business/finance (13), computer/mathematical (15), architecture/engineering (17), life/physical/social sciences (19), legal (23), arts/media/sports (27), sales (41), and office/administrative support (43). This is a mixed occupational universe, not exclusively graduate professional employment.

277 complete matched occupations cover 97.25% of baseline employment in the eligible nine-group universe. 117 have lower employment estimates in 2025 than in 2022. Their summed net contractions are 2,016,250 jobs. Other occupations expand by 4,044,390, so this universe grows by 2,028,140 overall. Do not call the 2.02 million a net loss across the whole universe, gross job destruction, or layoffs.

Most overrepresented: working directly with the public (+0.214 SD), administrative activities (+0.175), and working with computers (+0.057). Most underrepresented: strategy/objectives (-0.509), judging qualities (-0.498), coaching (-0.490), scheduling (-0.489), and consultation/advice (-0.483).

Analysis is underrepresented (-0.334), documenting/recording is approximately neutral (-0.011), and processing information is approximately neutral (-0.035). The broad claim that analytical production work is uniformly disappearing is not supported by this merge.

Office/administrative support supplies 62.69% of summed contractions but 29.48% of baseline employment. Sales supplies 17.06% of contractions and 21.18% of employment. These two groups account for 79.75% of contractions. Management supplies 15.83% of baseline employment and only 0.03% of contractions.

Largest contributing declines:

| Occupation | May 2022 | May 2025 | Change | Percent change |
|---|---:|---:|---:|---:|
| Customer service representatives | 2,879,840 | 2,595,750 | -284,090 | -9.9% |
| Cashiers | 3,296,040 | 3,089,410 | -206,630 | -6.3% |
| Bookkeeping/accounting/auditing clerks | 1,550,750 | 1,373,680 | -177,070 | -11.4% |
| Secretaries/admin assistants, excluding legal/medical/executive | 1,826,710 | 1,706,790 | -119,920 | -6.6% |
| Receptionists/information clerks | 1,011,170 | 910,180 | -100,990 | -10.0% |
| Computer programmers | 132,740 | 92,230 | -40,510 | -30.5% |

Customer-facing work is therefore not automatically insulated. O*NET's broad public-contact activity includes cashiers and customer-service work, and is not a measure of tact.

## Composition and sensitivity

The results file includes every activity for three windows ending in May 2025 (starting in 2022, 2023 and 2024), the all-occupation universe, the nine groups, a seven-group subset excluding sales and administrative support, exclusions of computers or office support, and each of the nine major groups separately.

Across all matched occupations, administrative activities, computer work, and information processing remain overrepresented in all three windows. Analysis remains underrepresented in all three. Coaching, strategy, relationships, negotiation and leadership remain underrepresented. The windows are correlated and are not independent replications.

Holding the broad occupation-family mix fixed sharply reduces the nine-group relationships. Strategy falls from -0.509 to -0.059 SD, leadership from -0.435 to -0.023, relationships from -0.335 to -0.050, and negotiation from -0.140 to +0.004. Administrative work switches from +0.175 to -0.063. The broad association substantially reflects contractions in clerical occupations alongside expansion in management and other professional occupations.

The seven-group professional subset provides a different descriptive comparison: 207 occupations, 70 contracting, 408,240 summed contractions, but 2,678,090 net employment growth overall. Its largest positive gaps are electronic-equipment repair (+0.414), creativity (+0.292), computer work (+0.226), and machine/process control (+0.215). Its largest negative gap is coaching (-1.060). After matching the seven major-family shares, computer work is +0.246, information processing +0.362, strategy -0.620, coaching -0.571, and negotiation -0.278. This narrower comparison is suggestive of greater resilience in roles involving organizational and interpersonal responsibilities, but it is a scope sensitivity, not independent or causal confirmation. It does not identify the age or seniority of people losing work. No significance claims are made.

## Calculation

For occupation o, let E0 and E1 be OEWS employment estimates and L = max(E0-E1, 0). A job gaining employment gets zero contraction weight; it remains in the baseline.

For each activity, calculate:

1. Baseline mean importance: sum(E0 * importance) / sum(E0).
2. Contraction-weighted mean: sum(L * importance) / sum(L).
3. Report (contraction mean - baseline mean) / baseline employment-weighted standard deviation across occupations.

Positive scores mean higher importance in the occupations accounting for contractions; negative scores mean lower importance. A +0.22 score is a 0.22-standard-deviation difference in occupational importance, not 22% more layoffs, an employment effect, or the proportion of tasks automated. Activities overlap and are not additive.

The CSV also reports means on a 0-100 scale using 25 * (original importance - 1). Original importance is 1-5. These ratings are not activity time shares. `gap_points` is a difference on this rescaled importance scale; `gap_sd` is the standardized ranking.

For the within-major comparison, calculate each major group's baseline employment-weighted mean importance. Weight those group means by each group's share of contractions. Subtract this counterfactual mean from the actual contraction profile and divide by the original sample's baseline standard deviation. This holds broad-family composition constant, but does not control industry, education, exposure, macroeconomic conditions or differences within families. It is a descriptive decomposition, not a regression estimate or causal test.

## Merge and coverage

- Retain national, cross-industry, all-ownership (`OWN_CODE=1235`) OEWS rows classified as `detailed`. Exclude aggregate hierarchy rows to avoid double counting.
- Collapse O*NET occupations to their seven-character SOC code, e.g. 11-3031.01 to 11-3031. Average available subtype ratings equally before attaching employment. OEWS does not provide weights for individual O*NET subtypes. This assumption is explicit; employment is never replicated across subtypes.
- Use exact SOC matches only. No fuzzy title match or imputation from neighboring occupations. Special OEWS aggregates without exact O*NET matches remain excluded. Some residual categories are represented only by available O*NET subtypes and may not perfectly represent their entire OEWS category.
- Suppress O*NET observations marked `Recommend Suppress=Y`. Missing observations are never zero-filled. Require all 41 activity means and usable employment in both endpoints for each analysis.
- 2022-25 all-occupation analysis: 756 complete occupations, 136.33 million baseline jobs, 92.21% of the employment in detailed OEWS codes with usable endpoints. End-period coverage is 91.82%. The nine-group subset covers 97.25% of baseline and 97.22% of endpoint employment. Coverage is not 100%; see the exclusion file. Some financial analysts, residual occupations, and OEWS aggregation codes are excluded.
- The `occupation_merge.csv` retains unmatched/incomplete records, four employment estimates, employment PRSEs, changes, subtype counts, and all activity scores. It is the reusable merged dataset, not just the final analysis sample.

## Limits that affect interpretation

BLS discourages time-series use of OEWS: each release combines six semiannual survey panels across three years. The main 2022-25 endpoints have nonoverlapping survey collection windows, reducing overlap relative to annual comparisons, but this does not eliminate estimation, classification, benchmark or sampling issues. Changes are approximate descriptive differences in employment estimates, not a measure of gross layoffs or which tasks firms stopped doing. A shrinking occupation can reflect fewer hires, exits, automation, demand shifts, recoding or other forces.

May 2025 is the latest OEWS endpoint available here; the analysis cannot establish what happened through November 2026. May 2022 to May 2025 also spans monetary tightening and other large changes, so lending-related declines cannot simply be attributed to AI.

O*NET 31.0 is a current profile snapshot, containing ratings collected in different years, including after the employment baseline. It is held fixed across endpoints. It is not a strictly pre-period task predictor and does not measure changing task content within occupations. A historical O*NET-vintage replication would be appropriate before making predictive claims.

The loss-weighting rule selects negative estimated changes; sampling noise can move occupations into that group. All nonzero declines are included, not just statistically significant ones. Employment PRSEs are retained, but cross-year covariance is unavailable here and no survey-based significance tests or causal estimates are presented. These are occupation-level comparisons; 41 activity rows are not 41 independent employment observations.

Age, worker tenure, seniority and hiring flows are absent. This dataset cannot directly establish displacement of entry-level workers or the return to experience.

## Files and reproduction

- `results/occupation_merge.csv`: reusable national employment/activity merge.
- `results/main_activity_ranking.csv`: all 41 activities in the nine-group 2022-25 comparison.
- `results/all_activity_results.csv`: all scopes/windows and within-major comparisons.
- `results/occupation_drivers.csv`, `major_group_drivers.csv`: occupations and groups behind contractions.
- `results/coverage_and_totals.csv`, `excluded_or_incomplete.csv`: coverage and exclusions.
- `results/activity_dictionary.csv`, `onet_to_soc.csv`: code meanings and subtype mapping.
- `results/activity_profiles.png`: chart of selected activities, with composition-adjusted comparisons.
- `data/`: four original OEWS national ZIP files.
- `input/prior/onet_research/raw/work_activities.csv`: original O*NET activity source.
- `results/oews_sources.json`, `onet_source_manifest.json`: URLs and input hashes.
- `analyze.py`, `make_report.py`: calculation, chart and reconciliation checks.

Dependencies: Python 3, pandas, numpy, openpyxl, matplotlib. From this directory run `python analyze.py`, then `python make_report.py`. No network access is required with the bundled source files.

## Sources and attribution

BLS national OEWS tables: https://www.bls.gov/oes/tables.htm

BLS time-series limitations: https://www.bls.gov/oes/oes_ques.htm

BLS May 2025 methodology: https://www.bls.gov/oes/2025/may/oes_tec.htm

O*NET 31.0, U.S. Department of Labor/Employment and Training Administration, National Center for O*NET Development: https://www.onetcenter.org/database.html

Work Activities source: https://www.onetcenter.org/dl_files/database/db_31_0_csv/work_activities.csv

O*NET data used under CC BY 4.0. Derived tables and chart are adaptations, not endorsed by O*NET. License: https://www.onetcenter.org/license_db.html
