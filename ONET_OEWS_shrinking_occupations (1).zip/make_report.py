from pathlib import Path
import pandas as pd, numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import shutil, json, zipfile
R=Path(__file__).resolve().parent
d=pd.read_csv(R/'results/all_activity_results.csv')
selection={
'Performing Administrative Activities':'Administrative activities',
'Working with Computers':'Working with computers',
'Processing Information':'Processing information',
'Analyzing Data or Information':'Analyzing data or information',
'Resolving Conflicts and Negotiating with Others':'Resolving conflicts / negotiating',
'Establishing and Maintaining Interpersonal Relationships':'Maintaining relationships',
'Guiding, Directing, and Motivating Subordinates':'Directing and motivating staff',
'Developing Objectives and Strategies':'Developing objectives / strategy',
'Coaching and Developing Others':'Coaching and developing others'}
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.spines.top':False,'axes.spines.right':False,'axes.spines.left':False,'axes.spines.bottom':False})
fig,axes=plt.subplots(1,2,figsize=(13.5,7.5),sharey=True)
fig.patch.set_facecolor('#f7f8fa')
for ax,scope,title in zip(axes,['all','nine_groups'],['All matched occupations','Nine occupational groups in your draft']):
 s=d[(d.scope==scope)&(d.start_year==2022)].set_index('activity').loc[list(selection)]
 y=np.arange(len(s));v=s.gap_sd.to_numpy()
 ax.set_facecolor('#f7f8fa');ax.axvline(0,color='#728093',lw=1)
 ax.barh(y,v,color=['#247d91' if x>0 else '#334c72' for x in v],height=.55)
 ax.plot(s.within_major_gap_sd,y,'o',mfc='white',mec='#151c29',ms=6,label='After matching broad occupation-family mix',zorder=3)
 ax.set_yticks(y,list(selection.values()));ax.tick_params(axis='y',length=0,labelsize=11)
 ax.set_xlim(-.65,.40);ax.set_xticks([-.6,-.4,-.2,0,.2,.4]);ax.grid(axis='x',alpha=.14)
 ax.set_axisbelow(True);ax.set_title(title,loc='left',fontsize=13,fontweight='bold',pad=20)
 ax.set_xlabel('Difference from baseline, standard deviations',fontsize=10,labelpad=12)
 for yi,vi in zip(y,v):ax.text(vi+(.018 if vi>=0 else -.018),yi,f'{vi:+.2f}',ha='left' if vi>=0 else 'right',va='center',fontsize=10,color='#172a40')
axes[0].invert_yaxis()
fig.suptitle('Administrative work is more prominent in shrinking occupations',x=.025,y=.97,ha='left',fontsize=19,fontweight='bold',color='#142d47')
fig.text(.025,.918,'May 2022–May 2025 · Selected O*NET activities · Positive = overrepresented; negative = underrepresented',fontsize=11,color='#526171')
fig.text(.025,.13,'Bars compare the activity profile of occupational net contractions with baseline employment.\nWhite circles hold the broad occupation-family mix constant. Much of the pattern reflects which families contracted.',fontsize=10,color='#34475c',linespacing=1.6)
fig.text(.025,.045,'Source: calculations from BLS OEWS and O*NET 31.0. All matched: 756 occupations; draft groups: 277.\nOEWS changes are descriptive estimates, not gross layoffs or causal AI effects. Activity importance is not a time share.',fontsize=9,color='#626d7b',linespacing=1.5)
fig.subplots_adjust(left=.285,right=.97,top=.83,bottom=.24,wspace=.17)
fig.savefig(R/'results/activity_profiles.png',dpi=170,facecolor=fig.get_facecolor())
plt.close(fig)

summary=pd.read_csv(R/'results/coverage_and_totals.csv')
occ=pd.read_csv(R/'results/occupation_merge.csv')
assert occ.soc.is_unique
assert len(d.query("scope=='nine_groups' and start_year==2022"))==41
assert np.allclose(summary.end_employment-summary.baseline_employment,summary.net_change)
assert np.allclose(summary.sum_net_expansions-summary.sum_net_contractions,summary.net_change)
drivers=pd.read_csv(R/'results/occupation_drivers.csv')
assert abs(drivers.share_contractions_pct.sum()-100)<1e-9
assert abs(drivers.baseline_share_pct.sum()-100)<1e-9
assert (drivers.loc[drivers.soc.eq('43-4051'),'employment_change_2022_25']==-284090).all()
print('Validated unique employment keys, 41-activity rankings, employment reconciliations, normalized weights and customer-service decline.')
