"""Reproducible O*NET 31.0 x national OEWS 2022-25 descriptive analysis.
Run with Python, pandas, numpy and openpyxl. Raw inputs accompany this script.
"""
from pathlib import Path
import json, zipfile, hashlib
import pandas as pd
import numpy as np

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'results'; OUT.mkdir(exist_ok=True)
RAW=ROOT/'input/prior/onet_research/raw'
YEARS=[2022,2023,2024,2025]
GROUPS=['11','13','15','17','19','23','27','41','43']
w=pd.read_csv(RAW/'work_activities.csv')
w=w[w['Scale ID'].eq('IM')].copy()
w.loc[w['Recommend Suppress'].eq('Y'),'Data Value']=np.nan
w['soc']=w['O*NET-SOC Code'].str[:7]
names=w[['Element ID','Element Name']].drop_duplicates().set_index('Element ID')['Element Name']
# Collapse O*NET suboccupations BEFORE attaching employment. Equal subtype
# weights are necessary because OEWS has no employment below its SOC code.
p=w.groupby(['soc','Element ID'])['Data Value'].mean().unstack()
counts=w.groupby('soc')['O*NET-SOC Code'].nunique()
cols=list(p.columns)
emp=None; manifest=[]
for year in YEARS:
    path=ROOT/f'data/oesm{year%100}nat.zip'
    z=zipfile.ZipFile(path)
    f=next(n for n in z.namelist() if n.endswith('.xlsx'))
    d=pd.read_excel(z.open(f))
    d=d[(d.O_GROUP=='detailed') & (d.OWN_CODE==1235) & (d.NAICS==0)].copy()
    assert d.OCC_CODE.is_unique
    d.TOT_EMP=pd.to_numeric(d.TOT_EMP,errors='coerce')
    d.EMP_PRSE=pd.to_numeric(d.EMP_PRSE,errors='coerce')
    d=d[['OCC_CODE','OCC_TITLE','TOT_EMP','EMP_PRSE']].rename(columns={'OCC_CODE':'soc','OCC_TITLE':f'title_{year}','TOT_EMP':f'emp_{year}','EMP_PRSE':f'prse_{year}'})
    emp=d if emp is None else emp.merge(d,on='soc',how='outer',validate='one_to_one')
    manifest.append({'file':str(path.relative_to(ROOT)),'url':f'https://www.bls.gov/oes/special-requests/oesm{year%100}nat.zip','sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'retrieved':'2026-11-16'})
emp['major']=emp.soc.str[:2]
emp['title']=emp['title_2025'].fillna(emp['title_2022'])
merged=emp.merge(p,on='soc',how='left',validate='one_to_one')
merged['onet_suboccupations']=merged.soc.map(counts)
merged['matched_activities']=merged[cols].notna().sum(axis=1)
merged['employment_change_2022_25']=merged.emp_2025-merged.emp_2022
merged['growth_pct_2022_25']=100*(merged.emp_2025/merged.emp_2022-1)
merged['contraction_2022_25']=(-merged.employment_change_2022_25).clip(lower=0)
merged.to_csv(OUT/'occupation_merge.csv',index=False)
w[['O*NET-SOC Code','Title','soc']].drop_duplicates().to_csv(OUT/'onet_to_soc.csv',index=False)
names.rename('activity').to_csv(OUT/'activity_dictionary.csv')
merged[merged.matched_activities<41][['soc','title','emp_2022','emp_2025','matched_activities']].to_csv(OUT/'excluded_or_incomplete.csv',index=False)

def mask(df,scope):
    if scope=='all':return pd.Series(True,index=df.index)
    if scope=='nine_groups':return df.major.isin(GROUPS)
    if scope=='seven_professional_groups':return df.major.isin(GROUPS[:-2])
    if scope=='nine_without_computers':return df.major.isin([g for g in GROUPS if g!='15'])
    if scope=='nine_without_office':return df.major.isin([g for g in GROUPS if g!='43'])
    if scope.startswith('major_'):return df.major.eq(scope[-2:])

results=[];summary=[];drivers=[]
for start in [2022,2023,2024]:
  for scope in ['all','nine_groups','seven_professional_groups','nine_without_computers','nine_without_office']+['major_'+g for g in GROUPS]:
    universe=merged[mask(merged,scope)&merged[f'emp_{start}'].gt(0)&merged.emp_2025.notna()].copy()
    # Complete-case activity panel ensures identical occupational coverage across
    # all 41 activities. Suppressed cells are never zero-filled.
    s=universe[universe.matched_activities.eq(41)].copy()
    b=s[f'emp_{start}'].to_numpy(); delta=s.emp_2025.to_numpy()-b
    loss=np.maximum(-delta,0); gain=np.maximum(delta,0)
    if loss.sum()==0:continue
    x=s[cols].to_numpy();base=np.average(x,axis=0,weights=b)
    sd=np.sqrt(np.average((x-base)**2,axis=0,weights=b))
    lm=np.average(x,axis=0,weights=loss)
    gm=np.average(x,axis=0,weights=gain) if gain.sum()>0 else np.full(len(cols),np.nan)
    # Baseline reweighted to the same major-family mix as contractions.
    cf=np.zeros(len(cols))
    for g in s.major.unique():
      idx=s.major.eq(g).to_numpy()
      cf+=loss[idx].sum()/loss.sum()*np.average(x[idx],axis=0,weights=b[idx])
    for j,c in enumerate(cols):
      results.append({'scope':scope,'start_year':start,'end_year':2025,'element':c,'activity':names[c],
        'baseline_importance_0_100':25*(base[j]-1),'contraction_importance_0_100':25*(lm[j]-1),
        'expansion_importance_0_100':25*(gm[j]-1),'gap_points':25*(lm[j]-base[j]),
        'gap_sd':(lm[j]-base[j])/sd[j],'within_major_gap_sd':(lm[j]-cf[j])/sd[j]})
    summary.append({'scope':scope,'start_year':start,'occupations':len(s),'shrinking':int((loss>0).sum()),
       'baseline_employment':b.sum(),'end_employment':s.emp_2025.sum(),'sum_net_contractions':loss.sum(),
       'sum_net_expansions':gain.sum(),'net_change':delta.sum(),
       'coverage_baseline_pct':100*b.sum()/universe[f'emp_{start}'].sum(),
       'coverage_end_pct':100*s.emp_2025.sum()/universe.emp_2025.sum()})
    if scope=='nine_groups' and start==2022:
      s['decline']=loss;s['share_contractions_pct']=100*loss/loss.sum()
      s['baseline_share_pct']=100*b/b.sum()
      s[['soc','title','major','emp_2022','emp_2025','employment_change_2022_25','growth_pct_2022_25','decline','share_contractions_pct','baseline_share_pct']].sort_values('decline',ascending=False).to_csv(OUT/'occupation_drivers.csv',index=False)
      s.groupby('major').agg(baseline_employment=('emp_2022','sum'),end_employment=('emp_2025','sum'),sum_contractions=('decline','sum'),contraction_share_pct=('share_contractions_pct','sum'),baseline_share_pct=('baseline_share_pct','sum')).to_csv(OUT/'major_group_drivers.csv')
r=pd.DataFrame(results).sort_values(['scope','start_year','gap_sd'],ascending=[True,True,False])
r.to_csv(OUT/'all_activity_results.csv',index=False)
pd.DataFrame(summary).to_csv(OUT/'coverage_and_totals.csv',index=False)
json.dump(manifest,open(OUT/'oews_sources.json','w'),indent=2)
main=r[(r.scope=='nine_groups')&(r.start_year==2022)]
main.to_csv(OUT/'main_activity_ranking.csv',index=False)
print(pd.DataFrame(summary).query("scope in ['all','nine_groups','seven_professional_groups']").to_string(index=False))
print('\nMAIN RANKING\n',main[['activity','gap_points','gap_sd','within_major_gap_sd']].to_string(index=False))
print('\nDRIVERS\n',pd.read_csv(OUT/'occupation_drivers.csv').head(15).to_string(index=False))
